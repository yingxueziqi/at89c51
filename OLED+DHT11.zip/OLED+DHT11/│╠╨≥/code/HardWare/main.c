#include "reg51.h"

#include "OLED.h"
#include "DHT11.h"
#include "Delay.h"
#include "Key.h"
#include "beep.h"

void main()
{
	 OLED_Init();
	 OLED_ColorTurn(0);
	 OLED_DisplayTurn(0);
	 DHT11_Rst();
	 DHT11_Read_Dat(&tempH, &tempL, &humiH, &humiL); 
	 display_Window1_OLED();
	 while(1){
		 Alarm_LED();
		 Window_Switch_Black();
		 	if(Window_count == 2 && flag == 1){
				flag = 0;
				display_Window2_OLED();
		 }else if(Window_count == 1 && flag == 2){
				flag = 0;
			  display_Window1_OLED();
		 }
			
	 }
}







