#include "BEEP.h"
#include "DHT11.h"
#include "Key.h"
void Alarm_LED(void)
{
    Collect_AND_Convert();
	  Set_Black();
		Add_Down_Black();
    if(Set_count == 0)            
    {
        if(Temp_f > set_TempH  ||  Temp_f < set_TempL   ||   humi_f > set_HumiH  ||  humi_f < set_HumiL)      //����ɼ����¶ȸ����趨���¶�......
        {
           	 LED = ~LED;
            DelayXms(200);
        }
        else LED = 1;
    }
}
