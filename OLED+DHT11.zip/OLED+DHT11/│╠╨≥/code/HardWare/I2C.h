
#ifndef __I2C_H
#define __I2C_H

#include "REG51.h"		  	 
 
#define  u8 unsigned char 
#define  u16 unsigned int
#define  u32 unsigned int

sbit OLED_SCL=P0^0;//SCL
sbit OLED_SDA=P0^1;//SDA

//-----------------函数声明----------------

//延时
void IIC_delay(void);
//起始信号
void I2C_Start(void);
//结束信号
void I2C_Stop(void);
//等待信号响应
void I2C_WaitAck(void); //测数据信号的电平
void Send_Byte(u8 dat);//写入一个字节
//----------------------------------------------




//-----------------OLED端口定义----------------

#define OLED_SCL_Clr() OLED_SCL=0
#define OLED_SCL_Set() OLED_SCL=1

#define OLED_SDA_Clr() OLED_SDA=0
#define OLED_SDA_Set() OLED_SDA=1

#define OLED_RES_Clr() OLED_RES=0
#define OLED_RES_Set() OLED_RES=1
//----------------------------------------------



#endif