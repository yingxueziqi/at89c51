#ifndef __Beep_H
#define __Beep_H
#include "reg51.h"

sbit LED = P1 ^ 1; 
void Alarm_LED(void);
#endif
