//.h文件负责声明  
#ifndef __DHT11_H_
#define __DHT11_H_

#include <reg51.h>
#include <intrins.h>
#include "delay.h"

sbit DHT11_IO = P1^0;

extern unsigned char  tempH, tempL, humiH, humiL;  
extern float Temp_f, humi_f; 
void DHT11_Rst(void);
char DHT11_Check(void);
unsigned char DHT11_Read_Byte(void);
char DHT11_Read_Dat(unsigned char *tempH, unsigned char *tempL, unsigned char *humiH, unsigned char *humiL);
void Collect_AND_Convert(void);
	

#endif