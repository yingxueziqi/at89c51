#ifndef __OLED_H
#define __OLED_H

#include "reg51.h"
#include "I2C.h" 	 

	
#define OLED_CMD  0	//写命令
#define OLED_DATA 1	//写数据

extern char flag;
void OLED_Init(void);
void OLED_WR_Byte(u8 dat,u8 mode);
void OLED_DisplayTurn(u8 i);
void OLED_ColorTurn(u8 i);
void OLED_Clear(void);
void Window_Switch_Black(void);
void OLED_ShowNum(u8 x,u8 y,long num,u8 len,u8 sizey);
void OLED_ShowChar(u8 x,u8 y,u8 chr,u8 sizey);
void INVERSE_OLED_ShowNum(u8 x,u8 y,u32 num,u8 len,u8 sizey);
void INVERSE_OLED_ShowChar(u8 x,u8 y,u8 chr,u8 sizey);
u32 oled_pow(u8 m,u8 n);
void OLED_Set_Pos(u8 x, u8 y);
void display_Window1_OLED(void);
void display_Window2_OLED(void);
void OLED_ShowChinese(u8 x,u8 y,u8 no,u8 sizey);
void INVERSE_OLED_ShowChinese(u8 x,u8 y,u8 no,u8 sizey);
#endif  
	 



