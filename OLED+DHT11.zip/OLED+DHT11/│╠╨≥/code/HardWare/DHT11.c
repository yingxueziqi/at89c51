#include "DHT11.h"
#include <intrins.h>
#include "OLED.h"
#include "Key.h"
unsigned char  tempH, tempL, humiH, humiL;  
float Temp_f, humi_f;      

void DHT11_Rst(void)
{
    DHT11_IO = 0;//主机拉低总线，至少延时18ms
    DelayXms(20);
    DHT11_IO = 1;//主机拉高总线 20- 40us
    Delay30us();
}

char DHT11_Check(void)
{
    unsigned int t = 0;
    while(DHT11_IO)  //等待低电平出现
    {
        t++;
        _nop_();
        if(t > 1000)
            return -1;
    }
    t = 0;
    while(!DHT11_IO)  //判断低电平的合法性  低电平是80us
    {
        t++;
        _nop_();
        if(t > 85)    //需大于80us
            return -2;
    }
    t = 0;
    while(DHT11_IO)  //判断高电平的合法性  低电平是80us
    {
        t++;
        _nop_();
        if(t > 85)    //需大于80us
            return -3;
    }
    return 0;    //如果DHT11正常，则返回0；异常则返回小于0
}

unsigned char DHT11_Read_Byte(void)
{
    unsigned char i;
    unsigned char t = 0;
    unsigned char dat = 0;
    for(i = 0; i < 8; i++) //高位先出，低位后出
    {
        while(!DHT11_IO)  //等待50us的低电平过去
        {
            t++;
            _nop_();
            if(t > 55)    //需大于50us
                return 0;
        }
        Delay40us();   //延时40us
        dat <<= 1;
        if(DHT11_IO == 1)
        {
            dat |= 1;
            t = 0;
            while(DHT11_IO)
            {
                t++;
                _nop_();
                if(t > 85)    //需大于80us
                    return 0;
            }
        }
    }
    return dat;   //出错则返回0，正确返回dat
}


char DHT11_Read_Dat(unsigned char *tempH, unsigned char *tempL, unsigned char *humiH, unsigned char *humiL)
{
    unsigned char i, buf[5];
    DHT11_Rst();
    if(DHT11_Check() == 0)   //正常
    {
////				buf[0] = DHT11_Read_Byte(); //接收湿度的高八位
////        buf[1] = DHT11_Read_Byte(); //接收湿度的低八位
////        buf[2] = DHT11_Read_Byte(); //接收温度的高八位
////        buf[3] = DHT11_Read_Byte(); //接收湿度的低八位
////        buf[4] = DHT11_Read_Byte(); //接收检验位

        TR0 = 0;//关闭时钟刷新的定时器
        for(i = 0; i < 5; i++)
        {
            buf[i] = DHT11_Read_Byte();
        }
        TR0 = 1;//关闭时钟刷新的定时器
        Delay40us();   //延时40us
        if((buf[0] + buf[1] + buf[2] + buf[3]) == buf[4])
        {   //校验
            *humiH = buf[0];//湿度高8位返回值
            *humiL = buf[1];
            *tempH = buf[2]; //温度高8位返回值
            *tempL = buf[3];

        }
        else
            return -1;   //如果校验出错。则返回-1
    }
    else
        return -2;
    return 0;
}
void Collect_AND_Convert(void) 
{
    DHT11_Read_Dat(&tempH, &tempL, &humiH, &humiL);   
    Temp_f = tempH + (float)tempL * 0.01;   
    humi_f = humiH + (float)humiL * 0.01;   
	  if(Window_count == 1){
		OLED_ShowChar(2 * 16 + 8, 0, tempH / 10 + 0x30, 16); //×Ö·û´®£¬ÎÂ¶È¸ß°ËÎ»
    OLED_ShowChar(3 * 16, 0, tempH % 10 + 0x30, 16); //×Ö·û´®£¬ÎÂ¶ÈµÍ°ËÎ»
    OLED_ShowChar(4 * 16, 0, tempL / 10 + 0x30, 16); //
    OLED_ShowChar(4 * 16 + 8, 0, tempL % 10 + 0x30, 16); //
	
	  OLED_ShowChar(2 * 16 + 8, 2, humiH / 10 + 0x30, 16); //×Ö·û´®£¬Êª¶È¸ß°ËÎ»
    OLED_ShowChar(3 * 16, 2, humiH % 10 + 0x30, 16); //×Ö·û´®£¬Êª¶ÈµÍ°ËÎ»
    OLED_ShowChar(4 * 16, 2, humiL / 10 + 0x30, 16); //
    OLED_ShowChar(4 * 16 + 8, 2, humiL % 10 + 0x30, 16); //
		}

		
}