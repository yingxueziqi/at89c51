#ifndef __delay_H_
#define __delay_H_
#include "delay.h"
#include <intrins.h>

void DelayXms(unsigned int xms); //Xms

//20ms延时函数
void Delay20ms();		//@11.0592MHz
//30us
void Delay30us();		//@11.0592MHz
void Delay40us();

#endif