#include "delay.h"
void DelayXms(unsigned int xms)
{
    unsigned char i,j;
    while(xms--)//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    {
        i = 2;
        j = 239;
        do
        {
            while (--j);
        }
        while (--i);
    }//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
}


//30us
void Delay30us()		//@11.0592MHz
{
	unsigned char data i;
	i = 11;
	while (--i);
}



//40us
void Delay40us()		//@11.0592MHz
{
	unsigned char data i;

	_nop_();
	i = 15;
	while (--i);
}

