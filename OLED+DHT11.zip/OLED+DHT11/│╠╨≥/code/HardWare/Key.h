#ifndef __Key_H
#define __Key_H
#include "reg51.h"

sbit SetButton = P1 ^ 2;       
sbit AddButton = P1 ^ 3;       
sbit DownButton = P1 ^ 4;       
sbit WindowButton = P1 ^ 5;

extern unsigned char Window_count; 
extern unsigned char Set_count; 

extern unsigned char set_TempH,set_TempL,set_HumiH,set_HumiL; 

void Set_Black(void);
void Add_Down_Black(void);

#endif
